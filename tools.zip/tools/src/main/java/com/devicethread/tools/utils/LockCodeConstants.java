package com.devicethread.tools.utils;

public class LockCodeConstants {
	
	public static String mastercodes[] = { "code_1514", "code_5595", "code_1503", "code_7159", "code_8627", "code_9881",
			"code_2238", "code_5069", "code_9342", "code_1266", "code_4557", "code_7858", "code_3405", "code_6010",
			"code_0656", "code_9597", "code_8599", "code_1685", "code_6819", "code_4555", "code_4208", "code_3553",
			"code_9726", "code_1784", "code_8000", "code_1392", "code_7680", "code_6894", "code_5340", "code_1829",
			"code_2909", "code_0056", "code_3002", "code_2450", "code_2750", "code_6044", "code_5658", "code_6771",
			"code_5935", "code_3109", "code_3778", "code_0404", "code_8626", "code_1717", "code_9227", "code_8852",
			"code_5894", "code_9251", "code_2281", "code_3181", "code_1566", "code_8820", "code_6262", "code_5947",
			"code_1182", "code_6275" };
	public static String staffCodes[] = { "code_7441", "code_4853", "code_1425", "code_5783", "code_9609", "code_2707",
			"code_7878", "code_2967", "code_7821", "code_5176", "code_7767" };
	
	public static String jsonPatPath="C:\\Users\\SSC\\eclipse_tools\\tools\\src\\main\\java\\com\\devicethread\\tools\\utils\\PAT.json";
	public static String token = "626523db-cbb4-4f3a-87a0-f48a1886cbde";

}
